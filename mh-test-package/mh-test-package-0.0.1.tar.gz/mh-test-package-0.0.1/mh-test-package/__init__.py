def addition(a, b):
    print("Adding...!")
    return a + b

